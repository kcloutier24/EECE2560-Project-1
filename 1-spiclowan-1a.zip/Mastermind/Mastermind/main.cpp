/*
File Name: main.cpp
Created by: Katherine Cloutier, Yizi Wang, & Zachary Spiegel
Course: EECE2560 Fundamentals of Engineering Algorithms
Semester: Fall 2022

This main.cpp file was developed for part a of the mastermind project. The main
objective of this file is to declare a secret code and print out the results
from the checkIncorrect and checkCorrect in the code class (code.h). Three 
sample vectors were provided, which were coded into the main function. The 
Pseudo-random secret code is also printed to the terminal.
*/



// Include statements
#include <iostream>
#include <stdlib.h>
#include <vector>
#include "code.h"

using namespace std;

int main()
// Main function to meet the requirements of testing the "Code" class
{
	// Variable declarations
	int num_digits, max_range;
	//bool won_game = false;

	// Declarations of three test vectors as defined in the project handout
	vector<vector<int>> guessVectors = 
	{ 
		{5, 0, 3, 2, 6}, 
		{2, 1, 2, 2, 2}, 
		{1, 3, 3, 4, 5} 
	};

	cout << "Welcome to the Mastermind Game!" << endl;
	cout << "Please enter the number of digits (n) that will be in the secret "
			"code: ";
	cin >> num_digits;		// User input to define # digits for secret code

	cout << endl << "Please enter the maximum range (m) of the random digits. "
					"The range will be from 0 to (m - 1): ";
	cin >> max_range;		// User input to define range of valid values

	// Declaration of Secret Code (SC) & Guess Code (GC) objects
	Code SC(num_digits, max_range);
	Code GC(num_digits, max_range);

	// Returns num_digits (n) and all valid values each digit can possibly be
	SC.getData();

	// Generates the n-digit secret code and prints to user
	SC.SecretCode();

	//// User-defined input to specify number of vectors
	//cout << "Please enter the number of desired samples: ";
	//cin >> num_samples;

	for (int i = 0; i < guessVectors.size(); i++)
	// Loops over the number of samples desired
	{
		//// Takes user inputs for each digit of the secret code
		//GC.GuessCode();

		cout << "Guess #" << i + 1 << "\n\n";

		// Writes the specific guess code from guessVectors based on i
		GC.GuessSampleCode(guessVectors[i]);

		// Returns number of correct digits in the correct location
		int num_correct = SC.checkCorrect(GC);

		// Returns number of correct digits in the incorrect location
		int num_incorrect = SC.checkIncorrect(GC);

		// Outputs result from checkCorrect function
		cout << "# of correct digits in the correct location for guess #" 
			 << i + 1 << ": " << num_correct << endl;

		// Outputs result from checkIncorrect method
		cout << "# of correct digits in the incorrect location for guess #"
			 << i + 1 << ": " << num_incorrect << "\n\n";

		//// Checks to see if Guess Code (GC) == Secret Code (GC)
		//if (num_correct == num_digits && num_incorrect == 0)
		//{
		//	cout << "You have sucessfully guessed the Secret Code! "
		//			"Congratulations!" << endl;

		//	won_game = true;
		//	break;
		//} // End if
	} // End if

	//// Prints if the game was lost
	//if (!won_game)
	//{
	//	cout << "You did not sucessfully guess the Secret Code! Better luck "
	//			"next time!" << endl;
	//}

	cout << "Game has ended! Goodbye!" << endl;

	return 0;
}

// End main.cpp