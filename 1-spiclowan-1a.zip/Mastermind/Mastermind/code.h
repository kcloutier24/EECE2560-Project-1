/*
File Name: code.h
Created by: Katherine Cloutier, Yizi Wang, & Zachary Spiegel
Course: EECE2560 Fundamentals of Engineering Algorithms
Semester: Fall 2022

This code.h file was developed for part a of the mastermind project. This file
serves as the declaration of the code class for the mastermind project. 
Some functions contained within the class include checkCorrect for checking the
# of correct digts in the correct location, checkIncorrect for checking the #
of correct digits in the incorrect location, and SecretCode for generating the
secret code.
*/



// Definition for header file
#ifndef HEADER
#define HEADER

// Include statements
#include <iostream>
#include <strstream>
#include <string>
#include <stdlib.h>
#include <iomanip>
#include <vector>
#include <ctime>

using namespace std;

class Code
{
	// Public members of Code class
	public:
		// Constructor of class
		Code(int n, int m);
		// Creates vector of valid digits
		void createValidDigVector();
		// Gets valid digits and size of vector
		void getData();
		// Generates secret code
		void SecretCode();
		// Passes defined guess code to guess code object
		void GuessSampleCode(const vector<int>& sampleCode);
		//// Allows user to input their guess code
		//void GuessCode();	// Not needed for Part A
		// Checks for correct values in correct location
		int checkCorrect(const Code &GC);
		// Checks for correct values in incorrect location
		int checkIncorrect(const Code &GC);

	// Private members of Code class
	private:
		// Number of digits for secret code
		int codeLength;
		// Upper limit for range of digits
		int rangeDigits;
		// Vector to store valid digits
		vector<int> validDigits;
		// Vector to store code data
		vector<int> code;
};


Code::Code(int n, int m)
// Constructor for length of code and valid range of digits. These digit(s) are
// initialized with the createdValidDigVector() function.
{
	codeLength = n;
	rangeDigits = m;

	createValidDigVector();
}


void Code::createValidDigVector()
// Inserts all valid integer values from 0 to rangeDgits - 1 into validDigits.
// These values are used for the secret code generation and bound checking the
// guess code.
{
	for (int i = 0; i < rangeDigits; i++)
	{
		validDigits.push_back(i);
	} // End for
}


void Code::getData()
// Prints codeLength to console as well as all values contained within the
// validDigits vector.
{
	cout << "\nThis is the number of digits in the secret code: " << codeLength
		 << " \n";

	cout << "These are the possible numbers for each digit: \n";

	for (int i = 0; i < rangeDigits; i++)
	{
		cout << "Number " << i + 1 << ": " << validDigits[i] << endl;

	} // End for

	cout << "\n";
}

void Code::SecretCode()
// Generates a secret code based on codeLength and values contained within
// validDigits.
{
	// Creates pseudo-random generator; not the same random values on every run
	srand(time(0));

	cout << "This is the secret code: \n";

	for (int i = 0; i < codeLength; i++)
	// Runs for the size of the desired code
	{
		// Generates secret code value here
		int random_val = rand() % rangeDigits;

		// Inserts random value into code vector
		code.push_back(random_val);

		// Prints value to console
		cout << "Number " << i + 1 << ": " << code[i] << "\n";
	} // End for

	cout << "Secret code is generated!! \n";
	cout << " \n";
}

void Code::GuessSampleCode(const vector<int> &sampleCode)
// Takes a vector sampleCode and writes it to the code vector contained within
// the code class. The vector sampleCode is passed by constant reference.
{
	// Ensures code vector is empty before writing new guess code to object
	code.clear();

	for (int i = 0; i < sampleCode.size(); i++)
	// Loops through each Guess value
	{
		// Inserts guess value into code object
		code.push_back(sampleCode[i]);

		cout << "Number " << i + 1 << ": " << sampleCode[i] << endl;
	}
}

//void Code::GuessCode()
//// Allows user to input their desired guess code by typing the value from
//// their keyboard. Error checking is implemented to verify the user input is
//// valid.
//{
//	int j;
//	int found = 0;
//
//	// Ensures code vector is empty before writing new guess code to object
//	code.clear();
//
//	cout << "Enter your guess numbers: \n";
// 
//	for (int i = 0; i < codeLength; i++)
//	// Runs for the size of the desired code
//	{
//		// User inputs guess value
//		cout << "Number " << i + 1 << ": ";
//		cin >> j;
//
//		// j must be between 0 and (rangeDigits - 1), which this while loop
//		// checks
//		while (validDigits[0] > j || validDigits[rangeDigits - 1] < j)
//		{
//			// Informs user of acceptable integer range and user enters a new
//			// value
//			cout << "Entry is not valid. Please enter an integer value between"
//				    " " << validDigits[0] << " and " 
//				 << validDigits[rangeDigits - 1] << ": ";
//
//			cin >> j;
//		} // End while
//
//		// Inserts guess value from user into code vector
//		code.push_back(j);
//	} // End for
//}


int Code::checkCorrect(const Code &GC)
// Compares the Guess Code and Secret Code to return the number of correct
// digits in the correct location. Returns an integer. Input GC is passed by
// constant reference.
{
	int correct_loc = 0;

	for (int i = 0; i < GC.codeLength; i++)
	// Runs for the size of the code
	{
		// Checks if the values are the same at the same location
		if (GC.code[i] == code[i])
		{
			correct_loc++;
		} // End if
	} // End for

	// Return # correct in correct location
	return correct_loc;
}


int Code::checkIncorrect(const Code &GC)
// Compares the Guess code and Secret Code to return the number of correct
// digits in the incorrect location. Returns an integer. Input GC is passed by
// constant reference.
{
	int correct_dig = 0;

	// Vector to store which values of the guess code have been accounted for
	vector<int> jToIgnore;

	for (int i = 0; i < codeLength; i++)
	// Loops over each digit of the secret code
	{
		for (int j = 0; j < GC.codeLength; j++)
		// Loops over each digit of the guess code
		{
			if ((GC.code[j] == code[i]) && (GC.code[i] != code[i])
				 && GC.code[j] != code[j])
			// Checks to see if Guess Code is correct in incorrect location
			{
				int repeatJ = 0;

				for (int k = 0; k < jToIgnore.size(); k++)
				// Loops through each value contained within vector
				{
					if (jToIgnore[k] == j)
					// Checks if j value has been accounted for
					{
						// Adds 1 to repeatJ
						repeatJ++;
					}
				}

				if (repeatJ == 0)
				// Case if j has not been accounted for
				{
					// Correct digit is desired. Add value of j to jToIgnore
					// vector
					correct_dig++;
					jToIgnore.push_back(j);

					// Force secret code (i) to next value to check
					break;
				}
			} // End if
		} // End for loop for GC
	} // End for loop for SC

	// Return # correct in incorrect location
	return correct_dig;
}

#endif

// End code.h