/*
File Name: main.cpp
Created by: Katherine Cloutier & Zachary Spiegel
Course: EECE2560 Fundamentals of Engineering Algorithms
Semester: Fall 2022

This main.cpp file was developed for part b of the mastermind project. The main
objective of this file is to instantiate a Mastermind object and call the
function playGame. This playGame function contains all the necessary logic to
play the game with the rules outlined in the handout for the project
*/



// Include statements
#include <iostream>
#include <stdlib.h>
#include <vector>
#include "mastermind.h"

using namespace std;

int main()
// Main function to meet the requirements of the completed Mastermind Game
{
	// Integers for storing n and m
	int numDigits, maxRange;

	cout << "Welcome to the Mastermind Game!" << endl;
	cout << "Please enter the number of digits (n) that will be in the secret "
		"code: ";
	cin >> numDigits;		// User input to define # digits for secret code

	cout << endl << "Please enter the maximum range (m) of the random digits. "
		"The range will be from 0 to (m - 1): ";
	cin >> maxRange;		// User input to define range of valid values

	// Initialize Mastermind Object with user inputs
	Mastermind mastermindGame(numDigits, maxRange);

	// Initialize Mastermind Object to defaults
	//Mastermind mastermindGame;

	// Call playGame function to run the Mastermind Game
	mastermindGame.playGame();
}

// End main.cpp