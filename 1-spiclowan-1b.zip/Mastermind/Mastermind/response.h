/*
File Name: response.h
Created by: Katherine Cloutier
Course: EECE2560 Fundamentals of Engineering Algorithms
Semester: Fall 2022

This response.h file was developed for part b of the mastermind project. This
file serves as storage for the checkCorrect and checkIncorrect values from the
Code class. Functions in this class include 'get' and 'set' functions for the
checkCorrect and checkIncorrect returns, as well as operator overloading ==
and <<. == was overloaded to compare two Response objects, and << was
overloaded to print numberCorrect and numberIncorrect to the console.
*/



//Definition for header file 
#ifndef RESPONSE_CLASS
#define RESPONSE_CLASS


// Include statements
#include <iostream>
#include <strstream>
#include <string>
#include <stdlib.h>
#include <iomanip>
#include <vector>
#include <ctime>

#include "mastermind.h"


using namespace std;


class Response
{
	// Public members of Response class
	public:
		// Constructor of Class
		Response();

		// Sets numberCorrect value
		void setCorrect(int r1);

		// Sets numberIncorrect value
		void setIncorrect(int r2);

		// Returns numberCorrect value
		int getCorrect() const;

		// Returns numberIncorrect value
		int getIncorrect() const;

		// == and << operator overloading for Response Class
		friend bool operator== (const Response& r1, const Response& r2);
		friend ostream& operator<< (ostream& ostr, const Response& t);

	// Private members of Response class
	private:
		int numberCorrect;
		int numberIncorrect;
};


Response::Response()
// Constructor of Response class that sets default values
{
	numberCorrect = 0;
	numberIncorrect = 0;
}


void Response::setCorrect(int correctLoc)
// Sets the private variable for numberCorrect (R1) to provided input to
// the function (correctLoc)
{
	numberCorrect = correctLoc;
}


void Response::setIncorrect(int correctDig)
// Sets the private variable for numberIncorrect (R2) to provided input to
// the function (correctDig)
{
	numberIncorrect = correctDig;
}


int Response::getCorrect() const
// Returns the private variable for numberCorrect (R1)
{
	
	return numberCorrect;

}


int Response::getIncorrect() const
// Returns the private variable for numberIncorrect (R2)
{
	
	return numberIncorrect;

}


// compare r1 and r2
bool operator== (const Response& r1, const Response& r2)
// Compares two response objects (r1 and r2). Returns true if both
// numberCorrect and numberIncorrect are equal in both objects. Returns false
// otherwise
{

	return (r1.numberCorrect == r2.numberCorrect) && 
		   (r1.numberIncorrect == r2.numberIncorrect);

}


ostream& operator<< (ostream& ostr, const Response& t)
// Overload stream operator << with lhs input (ostr) and rhs input (t), which
// is a response object. The output first prints numberCorrect (R1), then
// numberIncorrect (R2)
{
	// Ostr functionalities to be able to print strings to the console
	ios_base::fmtflags currentFlags = ostr.flags();
	char currentFill = ostr.fill();

	// Set fill char to ' ' and enable right justification
	ostr.fill(' ');
	ostr.setf(ios::right, ios::adjustfield);

	// Output the numberCorrect (R1) value
	ostr << "# of correct digits in the correct location: "
		 << t.numberCorrect << endl;

	// Output the numberIncorrect (R2) value
	ostr << "# of correct digits in the incorrect location: "
		 << t.numberIncorrect << endl;

	// Restore the fill char and the format flags
	ostr.fill(currentFill);
	ostr.setf(currentFlags);

	// Return the output
	return ostr;
}

#endif

// End Response.h