/*
File Name: mastermind.h
Created by: Yizi Wang, & Zachary Spiegel
Course: EECE2560 Fundamentals of Engineering Algorithms
Semester: Fall 2022

This mastermind.h file was developed for part b of the mastermind project. 
This file serves as main class that handles the backend logic of the mastermind
game. Functions in this class include humanGuess for the user input, 
getResponse for returning getCorrect and getIncorrect values from the Code 
class, isSolved for checking if the game has been won by the user, and playGame
which handles the general flow of the game.

Three values are given default values where needed as outlined in the project
handout. These include default values for codeLength (n) and rangeDigits (m),
as well as the number of guess opportunities allowed for the user.
*/



// Definition for header file
#ifndef MASTERMIND_CLASS
#define MASTERMIND_CLASS

// Include statements
#include <iostream>
#include <strstream>
#include <string>
#include <stdlib.h>
#include <iomanip>
#include <vector>
#include <ctime>

#include "code.h"
#include "response.h"

using namespace std;

// Declaring constant value for the number of guesses allowed by the user is.
// This is defined in the handout for the project as 10
const int NUMBER_GUESSES = 10;


class Mastermind
{
	// Public members of Mastermind Class
	public:
		// Default Constructor
		Mastermind();

		// Constructor to set values for codeLenght and rangeDigits
		Mastermind(int n, int m);

		// Prints secret code to the console
		void printSecretCode();

		// User makes guess with keyboard and returns Code object
		Code humanGuess();

		// Gets correct and incorrect values from user guess and returns
		// Response object
		Response getResponse(const Code& usersGuessCode);

		// Checks if the game is won and returns a boolean
		bool isSolved(Response& guessResponse);

		// Main logic to play Mastermind game
		void playGame();


	// Private members of Mastermind Class
	private:
		int codeLength;
		int rangeDigits;
		Code secretCode;
};


Mastermind::Mastermind() : secretCode(5, 10)
// Initializes codeLength to 5 and rangeDigits to 10 if no user inputs were
// defined.
{
	codeLength = 5;
	rangeDigits = 10;
}


Mastermind::Mastermind(int n, int m) : secretCode(n, m)
// Initializes codeLength and rangeDigits with values inputted by the user.
{
	codeLength = n;
	rangeDigits = m;
}


void Mastermind::printSecretCode()
// Prints the secret code to the console.
{
	cout << "Priting Secret Code: " << endl;

	secretCode.printCode();
}


Code Mastermind::humanGuess()
// Reads a guess from the keyboard and returns a code object for the guess.
// Functionality is built into code.h
{
	Code guessCode(codeLength, rangeDigits);

	guessCode.GuessCode();

	return guessCode;
}


Response Mastermind::getResponse(const Code& usersGuessCode)
// A code object is provided (guessCode), and a Response object is returned,
// denoting the correct and incorrect digits in the mastermind code.
{
	// Returns R1 and R2 values from code class 'checkCorrect' and 
	// 'checkIncorrect' functions
	int numCorrect = secretCode.checkCorrect(usersGuessCode);
	int numIncorrect = secretCode.checkIncorrect(usersGuessCode);

	// Instantiate a Response class object and set R1 and R2 values
	Response currentResponse;
	currentResponse.setCorrect(numCorrect);
	currentResponse.setIncorrect(numIncorrect);

	// Prints numCorrect and numIncorrect to the console from Response object
	// overloading of  '<<'
	cout << currentResponse;

	// Returns Response object currentResponse
	return currentResponse;
}


bool Mastermind::isSolved(Response& guessResponse)
// Function that returns True if the user sucessfully guessed the secret code;
// returns False otherwise. The response object (guessResponse) is passed in to
// determine whether the game has been won.
{

	if ((guessResponse.getCorrect() == codeLength) && 
		(guessResponse.getIncorrect() == 0))
	// Checks to see if the R1 value (numCorrect) is the same size as the guess
	// vector. Also confirms that R2 (numIncorrect) is 0, as there should be no
	// incorrect values if the game has been won.
	{
		// Return true if cases are met
		return true;
	}
	else
	{
		return false;
	}// End if

}


void Mastermind::playGame()
// Function that goes through the steps of the Mastermind game; initializes
// secret code, prints it to the screen, then takes guesses from the user until
// either the codemaker (computer) or code guesser (user) wins.
{
	// Bool to flag whether the game has been won
	bool wonGame = false;

	// Generates the secret code based on the n and m values specified
	secretCode.SecretCode();

	// Prints the secret code to the console
	printSecretCode();

	// For loop for the number of guesses allowed by the user
	for (int i = 0; i < NUMBER_GUESSES; i++)
	{
		// Instantiation of a Code object which holds the value of the current
		// guess from the user
		Code currentGuessCode = humanGuess();

		// Instantiation of a Response object which holds information about the
		// values from the checkCorrect and checkIncorrect functions of the 
		// code class.
		Response currentResponseVals = getResponse(currentGuessCode);

		// Checks to see if game has been won
		bool userWon = isSolved(currentResponseVals);

		// If game is won...
		if (userWon)
		{
			// Print message, set the wonGame flag to true, and exit for loop
			cout << "\nCongratulations! You have won the Mastermind Game by "
				 << "sucessfully guessing the secret code!";

			wonGame = true;
			break;
		} // End if

		cout << "You have " << (NUMBER_GUESSES - 1) - i << " guesses remaining"
			 << "!\n";
	} // End for

	// If the user lost the game...
	if (!wonGame)
	{
		// Print a losing message.
		cout << "\nYou did not win the Mastermind Game! Better luck next "
			 << "time!";
	} // End if

	// Final printing statement notifying user that the game is ending.
	cout << "\nGame is ending! Goodbye! \n\n";
}

#endif

// End mastermind.h